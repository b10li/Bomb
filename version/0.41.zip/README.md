# BomberZerg
epScript example starcraft usemap

epScript runs with EudDraft
https://github.com/phu54321/euddraft

epScript -> python -> starcraft trigger

.ees
is a setting savefile of Eud Editor
